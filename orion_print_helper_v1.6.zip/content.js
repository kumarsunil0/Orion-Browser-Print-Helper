(function() {
    // Domain filtering: Only run if site is in the allowed list
    const currentHost = window.location.hostname.toLowerCase();
    
    chrome.storage.local.get({ allowed_domains: ['delhivery.com'] }, (data) => {
        const domains = data.allowed_domains;
        const isAllowed = domains.some(domain => currentHost.includes(domain));
        
        if (!isAllowed) {
            console.log("Orion Print Helper: Domain not in allowed list. Skipping.");
            return;
        }

        console.log("Orion Print Helper Active on " + currentHost);
        injectOverride();
    });

    function injectOverride() {
        const code = `
            (function() {
                if (window.orion_helper_active) return;
                window.orion_helper_active = true;

                const originalOpen = window.open;

                window.open = function(url, name, specs) {
                    console.log("Orion Print Helper: Intercepting window.open. URL:", url);
                    
                    // Try to force name to _blank if it's not provided
                    const targetName = (name && name !== '_self') ? name : '_blank';

                    if (url && url !== 'about:blank' && url.length > 0) {
                        // 1. Try original window.open first with _blank
                        let newWin = originalOpen.call(window, url, '_blank');
                        
                        // 2. If it failed, try the link trick
                        if (!newWin || newWin.closed) {
                            console.log("Orion Print Helper: window.open failed, trying link click...");
                            try {
                                const link = document.createElement('a');
                                link.href = url;
                                link.target = '_blank';
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                return { closed: false, focus: function(){} };
                            } catch (e) {}
                        }

                        // 3. Last resort: navigation if we truly must, 
                        // but let's delay it slightly to give Orion a chance to open a tab
                        if (!newWin || newWin.closed) {
                            console.log("Orion Print Helper: Still no new tab. Checking if we should fallback...");
                            // If it's a tracking URL, we really want a new tab. 
                            // We only fallback to same tab if we are absolutely blocked.
                            window.location.href = url;
                        }
                        return newWin || window;
                    } else {
                        // For blank popups (document.write), we try to open a named window
                        console.log("Orion Print Helper: Handling blank popup...");
                        let win = originalOpen.call(window, '', 'print_popup');
                        if (win && win !== window) {
                            return win;
                        }
                        return window; 
                    }
                };

                // Aggressively force forms to new tabs
                document.addEventListener('submit', function(e) {
                    const form = e.target;
                    console.log("Orion Print Helper: Forcing form to _blank");
                    form.target = '_blank';
                }, true);

                // Aggressively force links to new tabs
                document.addEventListener('click', function(e) {
                    const a = e.target.closest('a');
                    if (a && a.href && !a.href.startsWith('javascript:')) {
                        if (a.href.includes('print') || a.href.includes('pdf') || a.target === '_blank') {
                            console.log("Orion Print Helper: Ensuring link uses _blank");
                            a.target = '_blank';
                        }
                    }
                }, true);

            })();
        `;

        const script = document.createElement('script');
        script.textContent = code;
        (document.head || document.documentElement).appendChild(script);
        script.remove();
    }

    injectOverride();
    setInterval(injectOverride, 2000);
})();
